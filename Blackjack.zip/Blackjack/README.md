# Blackjack - CSC582/495 final project

You wake up on the street next to a Casino. You don't remember who you are and why you are here, but there is a suitcase beside you. When you open the suitcase you find 2 million cash and a note--"Play Blackjack with a man wearing a Gucci basketball hat in the Casino." As you step into the Casino and play the game, you slowly retrieve your memory and discover a big secret.

## Getting Started

Our game has two different versions: The Unity version and the Ink version. The Unity version contains our most original setting, which has a Blackjack card game. The Ink version extends the story generations but without the Blackjack card game. Hope you can enjoy those two different versions!

### Unity Version

Play the Blackjack to retrieve your memory. The script will also display on the right side of the game window in a scroll view.

#### For MacOS

Open the **Blackjack_Mac_Unity**, run the playable application **Blackjack_Mac**.

If you encounter the permission problem, try to click **OK**, then rerun the application.

If it doesn't work, please follow the steps: https://www.reddit.com/r/macapps/comments/noemjj/here_is_how_to_fix_you_do_not_have_permission_to/

- Make sure Allow apps downloaded from: App Store and identified developers

- Go to terminal:

- - sudo spctl --master-disable
  - sudo chmod -R 755 XXXXXX (path to Blackjack_Mac)

#### For Windows

Open the **Blackjack_windows_Unity**, run the executable file **BlackjackVideo.exe**.

### Ink Version

Talk to the man that wearing a Gucci basketball to retrieve your memory.

Open the **Blackjack_Ink.zip**, run **index.html** to play the web version.

##Source Code

#### Unity Version

Open the **Unity_Source_code.zip**. It contains the **Assets**, **ProjectSettings**, and **Packages** of our unity game, which is also able to import as a Unity project.

#### Ink Version

**Blackjack.ink** is the source code of our Ink Version.



