using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundNumber : MonoBehaviour
{
    // The round number 
    public int round = 0;
    // Roundup when a round end 
    public void roundUp()
    {
        round++;
    }
    // Get the round number
    public int getRound()
    {
        return this.round;
    }
}
