using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NarrativeButton : MonoBehaviour
{


    public void OnMouseUp()
    {
        print("cao");
    }
}
