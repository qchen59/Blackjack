using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class KeepButton : MonoBehaviour
{
    // The keep playing button
    public Button keep;
    // Main camera
    public Camera mainCamera;
    public Camera NarrativeCam;
    // The deal button
    public Button dealBtn;
    // Roundup and narrative game object
    public GameObject roundOb;
    public GameObject narrative;

    // When the keep playing is clicked
    public void OnMouseUp()
    {
       if(roundOb.GetComponent<RoundNumber>().getRound() == 3)
        {
            keep.GetComponentInChildren<Text>().text = "Keep Playing";
            roundOb.GetComponent<RoundNumber>().round = 0;
        }
        keep.gameObject.SetActive(false);
        NarrativeCam.gameObject.SetActive(false);
        mainCamera.gameObject.SetActive(true);
        dealBtn.gameObject.SetActive(true);
        narrative.GetComponent<StoryLines>().playerWin = false;
    }
}
