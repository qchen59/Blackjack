using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GoPlay : MonoBehaviour
{
    // Go play the game
    public void loadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }
}
