﻿namespace Ink
{
    public class CommandLineInput
    {
        public bool isHelp;
        public bool isExit;
        public int? choiceInput;
        public int? debugSource;
        public string debugPathLookup;
        public object userImmediateModeStatement;
    }
}