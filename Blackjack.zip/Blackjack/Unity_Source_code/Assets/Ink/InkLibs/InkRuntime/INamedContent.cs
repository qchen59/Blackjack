﻿
namespace Ink.Runtime
{
	public interface INamedContent
	{
		string name { get; }
		bool hasValidName { get; }
	}
}

